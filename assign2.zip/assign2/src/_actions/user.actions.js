import { userConstants } from '../_constants';
import { history } from '../_helpers';
import axios from 'axios';
import { alertActions } from './';

export const userActions = {
    login,
    logout
};

function login(username, password) {
    return dispatch => {
        dispatch(request({ username }));

        axios.get(`https://swapi.co/api/people/?search=${username}`)
            .then(function (response) {
                // handle success
                console.log(response.data.next);
                let users = response.data.results;
                let filteredUsers = users.filter(user => {
                    return username === user.name && password === user.birth_year
                });
                if (filteredUsers.length) {
                    dispatch(success(filteredUsers[0]));
                    let data = {
                        name:filteredUsers[0].name
                    }
                    localStorage.setItem('user', JSON.stringify(data));
                    history.push('/');
                }else{
                    dispatch(failure("Incorrect username or password"));
                    dispatch(alertActions.error("Incorrect username or password"));
                }
            })
            .catch(function (error) {
                // handle error
                console.log(error);
            })
            .finally(function () {
                // always executed
            });
       
    };

    function request(user) { return { type: userConstants.LOGIN_REQUEST, user } }
    function success(user) { return { type: userConstants.LOGIN_SUCCESS, user } }
    function failure(error) { return { type: userConstants.LOGIN_FAILURE, error } }
}

function logout() {
    localStorage.removeItem('user');
    return { type: userConstants.LOGOUT };
}

