import { searchConstants } from '../_constants';
import { history } from '../_helpers';
import axios from 'axios';

export const searchActions = {
    search,
};

function search(searchTerm) {
    return dispatch => {
        dispatch(request({ searchTerm }));

        axios.get(`https://swapi.co/api/planets/?search=${searchTerm}`)
            .then(function (response) {
                // handle success
                 let planetLists = response.data.results;
                
                if (planetLists.length) {
                    dispatch(success(planetLists))   
                }
            })
            .catch(function (error) {
                // handle error
                dispatch(failure("Some thing went wrong"))  
            })
            .finally(function () {
                // always executed
            });
      
    };

    function request() { return { type: searchConstants.SEARCH_REQUEST } }
    function success(list) { return { type: searchConstants.SEARCH_SUCCESS, list } }
    function failure(error) { return { type: searchConstants.SEARCH_FAILURE, error } }
}

