import { searchConstants } from '../_constants';

const initialState = {
  searching: false,
  planetList : [],
  errorMsg : ""
};

export function searchReducer(state = initialState, action) {
  switch (action.type) {
    case searchConstants.SEARCH_REQUEST:
      return {
        searching: true,
        planetList : [],
        errorMsg : ""
      };
    case searchConstants.SEARCH_SUCCESS:
      return {
        searching: false,
        planetList: action.list,
        errorMsg : ""
      };
    case searchConstants.SEARCH_FAILURE:
      return {
        searching: false,
        planetList: [],
        errorMsg : action.error
      };
   
    default:
      return state
  }
}