import React, { Fragment } from 'react'
import { Link } from 'react-router-dom';

function PlanetComponent({planet}) {
   
    const heading = {
        color: 'black'
      };
      const planetText = {
        color: 'blue'
      };
      const planetWrap = {
          boader : '1px solid black',
          padding: '10px'
      }
      const aTag = {
          textDecoration: "none"
      }
      const url = planet.url.split("/")
      const id = url[url.length-2]
    return (
        
        <div style={planetWrap}>
             <Link to={`/plantDetail/${id}`} style={aTag}>
                <span> <span style={heading}>Name</span> : 
                <span style={planetText}> {planet.name} </span></span><br/>
                <span> <span style={heading}>Diameter</span> : 
                <span style={planetText}> {planet.diameter} </span></span><br/>
                <span> <span style={heading}>Rotation Period</span> : 
                <span style={planetText}> {planet.rotation_period} </span></span><br/>
                <span> <span style={heading}>Population </span> : 
                <span style={planetText}> {planet.population} </span></span><br/>
            </Link>
           
        </div>
    )
}

export default PlanetComponent
