import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { searchActions } from '../_actions';
import PlanetComponent from './PlanetComponent';
import {debounce} from 'throttle-debounce';


class HomePage extends React.Component {
    constructor(props) {
        super(props)
    
        this.state = {
             searchTerm : ""
        }
        this.handleChange = this.handleChange.bind(this);
        this.searchPlanetDetail = this.searchPlanetDetail.bind(this);
        this.callAjax = debounce(500, this.callAjax);
    }
    searchPlanetDetail(id){
        if(empty(id)){
            return "";
        }
        this.props.searchPlanetDetail(id)
    }

    handleChange(e) {
            const { name, value } = e.target;
        
            this.setState({ [name]: value },() =>{
                this.callAjax(this.state.searchTerm)
            });
           
      
    }
    callAjax(value) {
        this.props.search(this.state.searchTerm)
    
      }
    render() {
       
        const {   searchTerm } = this.state;
        const {   planetList } = this.props;

        const planetDiv = planetList.map( planet => <PlanetComponent key={planet.rotation_period+''+planet.diameter} planet={planet} />)
        
        return (
            <div className="col-md-6 col-md-offset-3">
                 <p>
                    <Link to="/login">Logout</Link>
                </p>
            <h2>Search</h2>
               <div className={'form-group' }>
                    <input type="text" className="form-control" name="searchTerm" value={searchTerm} onChange={this.handleChange} />
                </div>
               {planetDiv} 
        </div>
        );
    }
}

function mapState(state) {
    console.log(state)
    const { users, authentication,searchReducer } = state;
    const { user } = authentication;
    const { planetList} = searchReducer;
    return { user, users ,planetList};
}

const actionCreators = {
    search: searchActions.search,
    searchPlanetDetail: searchActions.searchPlanetDetail,
    
}

const connectedHomePage = connect(mapState, actionCreators)(HomePage);
export { connectedHomePage as HomePage };